// Comando customizado de login usando seletores do saucedemo
Cypress.Commands.add('login', (username, password) => {
  cy.visit('/') // baseUrl do config
  cy.get('#user-name').clear().type(username)
  cy.get('#password').clear().type(password, { log: false })
  cy.get('#login-button').click()
})
