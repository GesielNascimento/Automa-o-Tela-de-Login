// Testes de exemplo contra https://www.saucedemo.com/
// Este site público é feito para treinos de QA. IDs são estáveis.

describe('Login - Saucedemo', () => {
  beforeEach(() => {
    cy.visit('/')
  })

  it('deve fazer login com sucesso (usuário válido)', () => {
    cy.login(Cypress.env('valid_user'), Cypress.env('valid_pass'))
    // pós-login: deve existir o container de produtos
    cy.url().should('include', '/inventory.html')
    cy.get('.title').should('have.text', 'Products')
  })

  it('deve bloquear usuário travado (locked_out_user)', () => {
    cy.fixture('users').then(data => {
      const { username, password } = data.locked[0]
      cy.login(username, password)
      cy.get('[data-test="error"]').should('be.visible')
        .and('contain.text', 'Sorry, this user has been locked out.')
    })
  })

  it('deve exibir erro para credenciais inválidas', () => {
    cy.fixture('users').then(data => {
      data.invalid.forEach(creds => {
        cy.login(creds.username, creds.password)
        cy.get('[data-test="error"]').should('be.visible')
          .and('contain.text', 'Username and password do not match')
        // reseta para próxima tentativa
        cy.visit('/')
      })
    })
  })

  it('valida regras de formulário (campos obrigatórios)', () => {
    cy.visit('/')
    cy.get('#login-button').click()
    cy.get('[data-test="error"]').should('be.visible')
      .and('contain.text', 'Username is required')
  })
})
